import pygame

import ani
import globalVariables as gV

class player:

    def __init__(self, name):
        self.name = name
        self.pos = [100, 900]
        self.movementDirection = [0, 0]
        self.movementSpeed = 5

        self.currentAnimationType = "Idle"

        self.playerSpriteIdle = ani.MySprite("character_Player_Idle", ("Player/Idle",))
        self.playerSpriteWalkHori = ani.MySprite("spriteSheet_Player_Hori", ("Player/WalkHori", 8, 1, 4, 0, 4))
        self.playerSpriteWalkUp = ani.MySprite("character_Player_Up", ("Player/WalkUp",))
        self.playerSpriteWalkDown = ani.MySprite("character_Player_Down", ("Player/WalkDown",))

        self.animationSlowDown = 5
        self.animationSlowDownCounter = 0
        
    def doMove(self):
        for event in gV.pyEvents:
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_LEFT, pygame.K_a):
                    self.movementDirection[0] = -1
                    self.currentAnimationType = "Walk"
                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    self.movementDirection[0] = 1
                    self.currentAnimationType = "Walk"
                elif event.key in (pygame.K_UP, pygame.K_w):
                    self.movementDirection[1] = -1
                    self.currentAnimationType = "Walk"
                elif event.key in (pygame.K_DOWN, pygame.K_s):
                    self.movementDirection[1] = 1
                    self.currentAnimationType = "Walk"
            elif event.type == pygame.KEYUP:
                if event.key in (pygame.K_LEFT, pygame.K_a):
                    self.movementDirection[0] = 0
                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    self.movementDirection[0] = 0
                elif event.key in (pygame.K_UP, pygame.K_w):
                    self.movementDirection[1] = 0
                elif event.key in (pygame.K_DOWN, pygame.K_s):
                    self.movementDirection[1] = 0
                    
        self.pos = [x + y for x, y in zip(self.pos, [i * self.movementSpeed for i in self.movementDirection]  )]

    def update(self):
        #Movement
        self.doMove()
        
        #Set Animation Idle
        if self.movementDirection[0] == 0 and self.movementDirection[1] == 0:
            self.currentAnimationType = "Idle"

        #Updating Animations
        #Perform Every X Frames
        if self.animationSlowDownCounter < self.animationSlowDown:
            self.animationSlowDownCounter += 1
        else:
            self.updateAnimationSprites()
            self.animationSlowDownCounter = 0

        #Draw Character
        self.imgToDraw()

    def imgToDraw(self):        
        if self.currentAnimationType == "Idle":
            imageToBeDrawn = self.playerSpriteIdle.image
            self.playerSpriteIdle.update()
            return imageToBeDrawn
        elif self.currentAnimationType == "Walk":
            if self.movementDirection[1] == -1:
                imageToBeDrawn = self.playerSpriteWalkUp.image
                return imageToBeDrawn
            elif self.movementDirection[1] == 1:
                imageToBeDrawn = self.playerSpriteWalkDown.image
                return imageToBeDrawn
            elif self.movementDirection[0] == -1:
                imageToBeDrawn = pygame.transform.flip(self.playerSpriteWalkHori.image, True, False)
                return imageToBeDrawn
            elif self.movementDirection[0] == 1:
                imageToBeDrawn = self.playerSpriteWalkHori.image
                return imageToBeDrawn
            else:
                print("Exeption 1")
                imageToBeDrawn = self.playerSpriteIdle.image
                return imageToBeDrawn
        else:
            print("Exeption 2")
            imageToBeDrawn = self.playerSpriteIdle.image
            return imageToBeDrawn

    def updateAnimationSprites(self):
        if self.currentAnimationType == "Idle":
            self.playerSpriteIdle.update()
            self.playerSpriteWalkHori.reset()
            self.playerSpriteWalkUp.reset()
            self.playerSpriteWalkDown.reset()
        elif self.currentAnimationType == "Walk":
            if self.movementDirection[1] == -1:
                self.playerSpriteWalkUp.update()
                self.playerSpriteIdle.reset()
                self.playerSpriteWalkHori.reset()
                self.playerSpriteWalkDown.reset()
            elif self.movementDirection[1] == 1:
                self.playerSpriteWalkDown.update()
                self.playerSpriteIdle.reset()
                self.playerSpriteWalkHori.reset()
                self.playerSpriteWalkUp.reset()
            elif self.movementDirection[0] == -1 or self.movementDirection[0] == 1:
                self.playerSpriteWalkHori.update()
                self.playerSpriteIdle.reset()
                self.playerSpriteWalkUp.reset()
                self.playerSpriteWalkDown.reset()
            
